from pathlib import Path
import urllib.request,json,time
P=Path(__file__).parent
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
out=P/'allowed-newer-responses.json'; results=json.loads(out.read_text()) if out.exists() else []
done={x['id'] for x in results}
for c in json.loads((P/'allowed-cases.json').read_text()):
 if c['id'] in done:continue
 payload=dict(model='default_model',messages=c['messages'],temperature=0,seed=20260920,max_tokens=128,stream=False,chat_template_kwargs={'enable_thinking':False})
 record=dict(id=c['id'],case=c,request=payload,started=time.time())
 try:
  req=urllib.request.Request('http://127.0.0.1:8971/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
  with opener.open(req,timeout=180) as r: record['response']=json.load(r)
 except Exception as e:record['error']=str(e)
 record['ended']=time.time();results.append(record)
 tmp=out.with_suffix('.tmp');tmp.write_text(json.dumps(results,indent=2));tmp.replace(out)
 print(len(results),c['id'],record.get('response',{}).get('choices',[{}])[0].get('finish_reason',record.get('error')),flush=True)
 if 'error' in record:break
